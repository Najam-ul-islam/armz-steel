import { DashboardSkeleton } from "@/components/dashboard/dashboard-skeleton";

export default function OrdersLoading() {
  return <DashboardSkeleton />;
}