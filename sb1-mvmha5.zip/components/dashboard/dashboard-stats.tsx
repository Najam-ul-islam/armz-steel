import { Card } from "@/components/ui/card";
import { Package2, ArrowDownCircle, ArrowUpCircle, AlertCircle } from "lucide-react";

const stats = {
  totalProducts: 150,
  lowStock: 3,
  inboundToday: 12,
  outboundToday: 8,
};

export function DashboardStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card className="p-6">
        <div className="flex items-center space-x-2">
          <Package2 className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-medium">Total Products</h3>
        </div>
        <div className="mt-4">
          <p className="text-2xl font-bold">{stats.totalProducts}</p>
        </div>
      </Card>
      
      <Card className="p-6">
        <div className="flex items-center space-x-2">
          <AlertCircle className="h-4 w-4 text-destructive" />
          <h3 className="text-sm font-medium">Low Stock Items</h3>
        </div>
        <div className="mt-4">
          <p className="text-2xl font-bold">{stats.lowStock}</p>
        </div>
      </Card>
      
      <Card className="p-6">
        <div className="flex items-center space-x-2">
          <ArrowDownCircle className="h-4 w-4 text-green-500" />
          <h3 className="text-sm font-medium">Inbound Today</h3>
        </div>
        <div className="mt-4">
          <p className="text-2xl font-bold">{stats.inboundToday}</p>
        </div>
      </Card>
      
      <Card className="p-6">
        <div className="flex items-center space-x-2">
          <ArrowUpCircle className="h-4 w-4 text-blue-500" />
          <h3 className="text-sm font-medium">Outbound Today</h3>
        </div>
        <div className="mt-4">
          <p className="text-2xl font-bold">{stats.outboundToday}</p>
        </div>
      </Card>
    </div>
  );
}