import { Card } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

const lowStockItems = [
  { id: 1, name: "Steel Rebar", quantity: 50, minStock: 100 },
  { id: 2, name: "Steel Plate", quantity: 20, minStock: 50 },
  { id: 3, name: "Steel Pipe", quantity: 30, minStock: 75 },
];

export function LowStockAlerts() {
  return (
    <Card className="p-6">
      <div className="flex flex-col space-y-4">
        <div className="flex items-center space-x-2">
          <AlertCircle className="h-5 w-5 text-destructive" />
          <h3 className="text-lg font-medium">Low Stock Alerts</h3>
        </div>
        <div className="space-y-4">
          {lowStockItems.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
            >
              <div>
                <p className="font-medium">{item.name}</p>
                <p className="text-sm text-muted-foreground">
                  Min. Stock: {item.minStock}
                </p>
              </div>
              <div className="text-right">
                <p className="text-destructive font-medium">{item.quantity}</p>
                <p className="text-sm text-muted-foreground">Current Stock</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}